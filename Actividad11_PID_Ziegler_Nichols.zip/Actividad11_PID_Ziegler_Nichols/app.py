import streamlit as st
import numpy as np
import matplotlib.pyplot as plt
from scipy import signal

st.set_page_config(page_title='Actividad 11 | PID Ziegler-Nichols', layout='wide')
st.title('Actividad 11 · Sintonización PID por Ziegler–Nichols')
st.caption('Control clásico · Método de ganancia última (oscilación sostenida)')
st.latex(r'G(s)=\frac{1}{(s+3)(s+4)(s+8)}=\frac{1}{s^3+15s^2+68s+96}')

# Routh para 1 + K G(s) = 0: s³ + 15s² + 68s + (96+K) = 0
# Fila s¹: (15*68 - (96+K))/15. Oscilación marginal cuando K=924.
Ku = 15*68-96
omega_u = np.sqrt(68)
Tu = 2*np.pi/omega_u
Kc = 0.6*Ku
Ti = 0.5*Tu
Td = 0.125*Tu
Ki = Kc/Ti
Kd = Kc*Td

st.subheader('1. Ganancia última y periodo de oscilación')
st.markdown('Con un controlador **solo proporcional** y realimentación unitaria, la ecuación característica es:')
st.latex(r'1+K G(s)=0\quad\Rightarrow\quad s^3+15s^2+68s+(96+K)=0')
st.markdown('Tabla de Routh–Hurwitz:')
st.latex(r'\begin{array}{c|cc}s^3&1&68\\s^2&15&96+K\\s^1&\frac{924-K}{15}&0\\s^0&96+K&\end{array}')
st.markdown('La oscilación sostenida aparece cuando la fila de $s^1$ se hace cero. La ecuación auxiliar es $15s^2+(96+K_u)=0$.')
st.latex(r'K_u=924,\qquad 15s^2+1020=0\Rightarrow\omega_u=\sqrt{68}')
st.latex(r'T_u=\frac{2\pi}{\sqrt{68}}')
a,b=st.columns(2)
a.metric('Ganancia última Ku',f'{Ku:.3f}')
b.metric('Periodo último Tu',f'{Tu:.5f} s')

st.markdown('**Comprobación gráfica de la oscilación sostenida** (control P con $K=K_u$):')
t_osc=np.linspace(0,12,2500)
# T(s)=Ku/(s³+15s²+68s+96+Ku), marginalmente estable
sys_osc=signal.TransferFunction([Ku],[1,15,68,96+Ku])
_,y_osc=signal.step(sys_osc,T=t_osc)
fig,ax=plt.subplots(figsize=(10,3.8))
ax.plot(t_osc,y_osc,label='Respuesta con K = Ku')
ax.axhline(1,color='gray',linestyle='--',label='Referencia = 1')
ax.set(xlabel='Tiempo (s)',ylabel='Salida y(t)',title='Oscilación sostenida con ganancia última')
ax.grid(alpha=.3);ax.legend();st.pyplot(fig);plt.close(fig)
st.info('La separación entre dos máximos consecutivos es Tu ≈ %.5f s. El sistema con K = Ku está en el límite de estabilidad: esta gráfica NO es la respuesta del PID final.'%Tu)

st.subheader('2. Tabla clásica de Ziegler–Nichols (método de oscilación)')
st.table({'Controlador':['P','PI','PID'], 'Kc':['0.50 Ku','0.45 Ku','0.60 Ku'],'Ti':['—','Tu / 1.2','Tu / 2'],'Td':['—','—','Tu / 8']})
st.latex(r'K_c=0.6K_u=0.6(924)=554.4')
st.latex(r'T_i=\frac{T_u}{2}=\frac{\pi}{\sqrt{68}}')
st.latex(r'T_d=\frac{T_u}{8}=\frac{\pi}{4\sqrt{68}}')
st.latex(r'C(s)=K_c\left(1+\frac{1}{T_i s}+T_d s\right)=K_d s+K_c+\frac{K_i}{s}')
cols=st.columns(5)
for col,label,val,unit in zip(cols,['Kc','Ti','Td','Ki = Kc/Ti','Kd = Kc·Td'],[Kc,Ti,Td,Ki,Kd],['','s','s','','']):
    col.metric(label,f'{val:.5f} {unit}')

st.subheader('3. PID en lazo cerrado y respuesta al escalón unitario')
st.latex(r'T(s)=\frac{C(s)G(s)}{1+C(s)G(s)}=\frac{K_d s^2+K_c s+K_i}{s^4+15s^3+(68+K_d)s^2+(96+K_c)s+K_i}')
with st.sidebar:
    st.header('Opciones de simulación')
    duracion=st.slider('Duración de la gráfica (s)',5,60,20)
    tolerancia=st.selectbox('Banda de establecimiento', [2,5],index=0)
    st.caption('Los valores PID se calculan automáticamente con Z–N clásico.')
num=[Kd,Kc,Ki]
den=[1,15,68+Kd,96+Kc,Ki]
sys_cl=signal.TransferFunction(num,den)
t=np.linspace(0,duracion,max(3000,duracion*250))
_,y=signal.step(sys_cl,T=t)
poles=np.roots(den)
stable=bool(np.all(np.real(poles)<0))
peak=float(np.max(y));overshoot=max(0,(peak-1)*100)
# Establishment: last sample outside band, only claim if window reaches steady state
outside=np.where(np.abs(y-1)>tolerancia/100)[0]
settle=t[outside[-1]+1] if len(outside) and outside[-1]+1<len(t) else (0 if not len(outside) else None)
fig,ax=plt.subplots(figsize=(11,4.5))
ax.plot(t,y,label='Sistema con PID Z–N',linewidth=2)
ax.axhline(1,linestyle='--',color='black',label='Referencia (1)')
ax.axhline(1+tolerancia/100,linestyle=':',color='gray')
ax.axhline(1-tolerancia/100,linestyle=':',color='gray',label=f'Banda ±{tolerancia}%')
ax.set(xlabel='Tiempo (s)',ylabel='Salida y(t)',title='Respuesta en lazo cerrado al escalón unitario')
ax.grid(alpha=.3);ax.legend();st.pyplot(fig);plt.close(fig)
c1,c2,c3,c4=st.columns(4)
c1.metric('Estabilidad','Estable' if stable else 'No estable')
c2.metric('Sobreimpulso',f'{overshoot:.2f}%')
c3.metric('Tiempo establecimiento',f'{settle:.3f} s' if settle is not None else 'Ampliar ventana')
c4.metric('Error estacionario teórico','0')
st.markdown('**Validación:** la acción integral hace que el valor final teórico ante un escalón unitario sea 1 (si el lazo cerrado es estable). El método Z–N clásico puede producir sobreimpulso; no busca necesariamente una respuesta sin oscilaciones.')
st.markdown('**Polos del lazo cerrado:** '+', '.join(f'{p.real:.4f}{p.imag:+.4f}j' for p in poles))

st.subheader('4. Comparación: planta original vs. PID')
plant=signal.TransferFunction([1],[1,15,68,96])
_,yp=signal.step(plant,T=t)
fig,ax=plt.subplots(figsize=(10,3.7))
ax.plot(t,yp,label='Planta sin controlador (lazo abierto)')
ax.plot(t,y,label='Con PID (lazo cerrado)')
ax.axhline(1,color='black',linestyle='--',label='Referencia 1')
ax.set(xlabel='Tiempo (s)',ylabel='Salida',title='Comparación ante escalón unitario')
ax.grid(alpha=.3);ax.legend();st.pyplot(fig);plt.close(fig)
st.caption('La planta sin controlador tiende a G(0)=1/96 ≈ 0.01042. El PID en lazo cerrado sigue la referencia unitaria.')
st.subheader('5. Conclusión')
st.write('Mediante Routh–Hurwitz se encontró Ku = 924 y, a partir de la frecuencia de oscilación, Tu ≈ %.5f s. La tabla clásica de Ziegler–Nichols permitió calcular Kc = %.2f, Ti ≈ %.5f s y Td ≈ %.5f s. La simulación confirma que el lazo cerrado es %s y que la salida converge a la referencia de 1; puede presentar sobreimpulso por tratarse de una sintonización inicial clásica.'%(Tu,Kc,Ti,Td,'estable' if stable else 'inestable'))
