# Actividad 11 — PID Ziegler–Nichols

## Ejecución en Visual Studio Code

1. Abre esta carpeta en VS Code.
2. Abre Terminal > Nueva terminal.
3. Instala las dependencias:

   ```bash
   python -m pip install -r requirements.txt
   ```

4. Inicia la app:

   ```bash
   python -m streamlit run app.py
   ```

## Resultados analíticos

Planta: G(s)=1/[(s+3)(s+4)(s+8)].

Polinomio característico con P: s³+15s²+68s+(96+K).

Routh: (924-K)/15=0 -> Ku=924.

Ecuación auxiliar: 15s²+1020=0 -> ωu=sqrt(68), Tu=2π/sqrt(68).

PID Z–N clásico: Kc=0.6Ku; Ti=Tu/2; Td=Tu/8.

El PID ideal es C(s)=Kc(1+1/(Ti*s)+Td*s).

Lazo cerrado: T(s)=(Kd*s²+Kc*s+Ki)/(s⁴+15s³+(68+Kd)s²+(96+Kc)s+Ki).

## Relación con la rúbrica

- C1: cálculo de Ku, Tu y gráfica de oscilación sostenida.
- C2: tabla Z–N y sustituciones matemáticas.
- C3: código de lazo cerrado, escalón unitario y validación de convergencia a 1.
- S1: redacta el reporte con tus propias palabras y cita los materiales utilizados. No se puede garantizar un porcentaje de similitud de Turnitin.
